#include <stdio.h>
#include <stdlib.h>


#define ITTERATIVE_ARRAY_BEGIN(arrptr, arr_size, start_index, scan_size, out_index)\
    unsigned int itterative_count = 0;\
    for(int j = (start_index); itterative_count < (scan_size); itterative_count++, j = (j+1)%(arr_size) ){\
        out_index = *(arrptr + j);\

#define ITTERATIVE_ARRAY_END }}


int
main (int argc, int ** argv){
    unsigned int arr[] = {1,2,3,4,5,6,7,8,9,10};
    unsigned int i;
    ITTERATIVE_ARRAY_BEGIN(arr,10,5,10,i){
    printf("arr[%u] = %u\n",itterative_count, i);
    ITTERATIVE_ARRAY_END
    return 0;
}